package com.delta.bookshelf;

/**
 * Created by learnovate on 3/13/14.
 */
public class MyInfo {

    int myAge = 33;
    String myName = "Adam";
    boolean isMale = true;
    char middleInitial = 'J';
    float myHeightInMeters = 1.87f;

    private void updateMyInfo(){
        myAge = 34;
        myName = "Adam Lupu";   
    }

}
